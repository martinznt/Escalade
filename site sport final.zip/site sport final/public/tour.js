// tour.js — visite guidée immersive : l'app va elle-même sur chaque page, met en lumière l'élément expliqué
// (le reste de l'écran est assombri) et affiche une bulle avec une flèche qui le pointe.
// Précédent / Suivant / Passer ; flèches du clavier et Échap ; s'adapte à la rotation et au défilement.
import { h } from './ui.js';
import { S, ACT, go } from './state.js';

// [onglet, sous-page, sélecteur de l'élément à montrer, titre, texte]
const STEPS = [
  ['home', 'dash', '.hero', '👋 Bienvenue !', 'Voici ton accueil : ta semaine en un coup d’œil. On fait le tour ensemble en 30 secondes.'],
  ['home', 'dash', '.quick .qa.pri', '✨ Une séance pour toi', 'Touche ici : l’app prépare une séance adaptée à ton niveau, ton temps et ton matériel.'],
  ['home', 'dash', '.quick .qa:nth-child(2)', '📚 Tes séances', 'Retrouve, lance ou modifie les séances que tu as enregistrées.'],
  ['library', 'generate', '.gen .chips.big', '🎯 Deux choix, c’est tout', 'Choisis ton sport et combien de temps tu as…'],
  ['library', 'generate', '[data-act=genPlan]', '👀 Aperçu avant de commencer', '…puis l’app te montre ce qu’elle prévoit. Tu peux ajuster, puis lancer la séance ▶.'],
  ['progress', 'summary', '.kpis, .card.hero', '📈 Tes progrès', 'Tes chiffres et tes records apparaissent ici, comparés uniquement à toi-même.'],
  ['profile', 'home', '.tiles', '👤 Ton profil', 'Tout ce que l’app sait de toi : sports, mesures, objectifs, matériel. Touche une tuile pour la modifier.'],
  ['settings', 'main', '.palette', '🎨 À ton image', 'Change les couleurs, le thème ou la taille du texte. Ça suit ton compte sur tous tes appareils.'],
  ['settings', 'help', '[data-act=helpTour]', '🧭 C’est parti !', 'Tu pourras relancer cette visite quand tu veux, ici. Bon entraînement 💪'],
];
const T = { i: -1, onEnd: null, raf: 0 };

export function startTour({ onEnd } = {}) {
  T.onEnd = onEnd || null;
  let root = document.getElementById('tour');
  if (!root) { root = document.createElement('div'); root.id = 'tour'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); document.body.appendChild(root); }
  document.body.classList.add('touring');
  window.addEventListener('resize', place); window.addEventListener('scroll', place, true); document.addEventListener('keydown', onKey);
  show(0);
}
export const tourActive = () => T.i >= 0;
function onKey(e) { if (T.i < 0) return; if (e.key === 'ArrowRight') show(T.i + 1); else if (e.key === 'ArrowLeft') show(T.i - 1); else if (e.key === 'Escape') end(); }
async function show(i) {
  if (i < 0) return;
  if (i >= STEPS.length) return end();
  T.i = i;
  const [tab, sub, sel] = STEPS[i];
  if (S.tab !== tab || S.sub[tab] !== sub) go(tab, sub);
  const el = await waitFor(sel);
  if (T.i !== i) return; // l'utilisateur a déjà changé d'étape
  if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  draw(el);
}
function waitFor(sel, ms = 1500) {
  return new Promise((res) => { const t0 = Date.now(); const tick = () => { const el = document.querySelector(sel); if (el && el.getBoundingClientRect().height > 0) return res(el); if (Date.now() - t0 > ms) return res(null); requestAnimationFrame(tick); }; tick(); });
}
function draw(el) {
  const [, , , title, text] = STEPS[T.i], root = document.getElementById('tour'); if (!root) return;
  const last = T.i === STEPS.length - 1;
  root.innerHTML = h`<div class="tour-spot"></div><div class="tour-bubble tour"><i class="tour-arrow"></i><button class="tour-x" data-act="tourEnd" aria-label="Quitter la visite">✕</button>
    <div class="tour-step">${T.i + 1} / ${STEPS.length}</div><h3>${title}</h3><p>${text}</p>
    <div class="dots">${STEPS.map((_, k) => h`<i class="${k === T.i ? 'on' : ''}"></i>`)}</div>
    <div class="row">${T.i > 0 ? h`<button class="btn sm" data-act="tourPrev">‹ Retour</button>` : h`<button class="btn sm ghost" data-act="tourEnd">Passer</button>`}<span class="grow"></span>
      ${last ? h`<button class="btn pri" data-act="tourEnd">C’est compris !</button>` : h`<button class="btn pri" data-act="tourNext">Suivant ›</button>`}</div></div>`.s;
  T.el = el; place();
  root.querySelector('.tour-bubble [data-act=tourNext], .tour-bubble [data-act=tourEnd]')?.focus({ preventScroll: true });
}
/** Place le halo sur l'élément et la bulle au-dessus ou en dessous, avec la flèche qui le pointe. */
function place() {
  cancelAnimationFrame(T.raf);
  T.raf = requestAnimationFrame(() => {
    const root = document.getElementById('tour'); if (!root || T.i < 0) return;
    const spot = root.querySelector('.tour-spot'), bub = root.querySelector('.tour-bubble'), arrow = root.querySelector('.tour-arrow');
    const vw = window.innerWidth, vh = window.innerHeight, pad = 8;
    if (!T.el || !document.body.contains(T.el)) {
      spot.style.cssText = `left:${vw / 2}px;top:${vh / 2}px;width:0;height:0`;
      bub.style.cssText = `left:16px;right:16px;top:${Math.max(16, vh / 2 - 120)}px`; arrow.style.display = 'none'; return;
    }
    const r = T.el.getBoundingClientRect();
    spot.style.cssText = `left:${r.left - pad}px;top:${r.top - pad}px;width:${r.width + 2 * pad}px;height:${r.height + 2 * pad}px`;
    const bw = Math.min(360, vw - 32), bh = bub.offsetHeight || 190;
    const below = r.bottom + pad + 14 + bh < vh - 90 || r.top - pad - 14 - bh < 60;
    const top = below ? Math.min(vh - bh - 16, r.bottom + pad + 14) : Math.max(16, r.top - pad - 14 - bh);
    const left = Math.max(16, Math.min(vw - bw - 16, r.left + r.width / 2 - bw / 2));
    bub.style.cssText = `left:${left}px;top:${top}px;width:${bw}px`;
    arrow.style.display = ''; arrow.className = 'tour-arrow ' + (below ? 'up' : 'down');
    arrow.style.left = `${Math.max(18, Math.min(bw - 18, r.left + r.width / 2 - left))}px`;
  });
}
function end() {
  T.i = -1; document.getElementById('tour')?.remove(); document.body.classList.remove('touring');
  window.removeEventListener('resize', place); window.removeEventListener('scroll', place, true); document.removeEventListener('keydown', onKey);
  go('home', 'dash');
  const cb = T.onEnd; T.onEnd = null; cb?.();
}
ACT.tourNext = () => show(T.i + 1);
ACT.tourPrev = () => show(T.i - 1);
ACT.tourEnd = () => end();
